<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

use App\Models\Kasir;
use App\Models\Tagihan;

use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\PrintConnectors\RawbtPrintConnector;
use Mike42\Escpos\CapabilityProfile;
use Illuminate\Support\Facades\Storage;
use Mike42\Escpos\EscposImage;
use Mike42\Escpos\ImagickEscposImage;

use Jenssegers\Agent\Agent;

use Exception;

class KasirController extends Controller
{
    public function bayar($id){
        $agent = new Agent();
        if($agent->isDesktop()){
            $platform = 'desktop';
        }
        else{
            $platform = 'mobile';
        }

        if($platform == 'mobile'){
            try {
                //Connector
                $profile = CapabilityProfile::load("POS-5890");
                $connector = new RawbtPrintConnector();
                $printer = new Printer($connector, $profile);
    
                // Content
                $printer->setJustification(Printer::JUSTIFY_CENTER);
                $printer->text("Fahni Amsyari.\n");
                $printer->selectPrintMode();
                $printer->text("Levind Sein.\n");
                $printer->feed();
            
                //Print
                $printer->cut();
                $printer->pulse();
            
            } catch (Exception $e) {
                return redirect()->route('kasirindex')->with('error','Kesalahan Sistem');
            } finally {
                $printer->close();
            }
        }
        else{
            try{
                $test1 = 'Rp. '.number_format(20000000);
                $test2 = 'Rp. '.number_format(100000);
                $test3 = 'Rp. '.number_format(57289918);

                $connector = new WindowsPrintConnector('EPSONLQ');
                        
                $printer = new Printer($connector);

                // Content
                $printer->text("=================================================================================================\n");
                $printer->text("                           BADAN PENGELOLA PUSAT PERDAGANGAN CARINGIN                            \n");
                $printer->text("                                 KEMITRAAN KOPPAS INDUK BANDUNG                                  \n");
                $printer->text("                                        SEGI PEMBAYARAN                                          \n");
                $printer->text("   Fahni Amsyari                                                        Kasir : Fahni Amsyari    \n");
                $printer->text("   A-1-001                                                            Tagihan : Oktober 2020     \n");
                $printer->text("----- FASILITAS -----------  AWAL -------- AKHIR --------- PAKAI ---------------- JUMLAH --------\n");
                $printer->text("      Listrik                                200 kWH                                             \n");
                $printer->text("      Air Bersih                             50 M3                                               \n");
                $printer->text("      Keamanan & IPK                         2 unit                                              \n");
                $printer->text("      Kebersihan                             2 unit                                              \n");
                $printer->text("      Air Kotor                                                                                  \n");
                $printer->text("      Tunggakan                                                                                  \n");
                $printer->text("      Denda                                                                                      \n");
                $printer->text("      Lain - Lain                                                                                \n");
                $printer->text("-------------------------------------------------------------------------------------------------\n");
                $printer->text("   Total Pembayaran                                                                              \n");
                $printer->text("-------------------------------------------------------------------------------------------------\n");
                $printer->text("            Tanggal : 28 November 2020 - Total Pembayaran telah termasuk PPN                     \n");
                $printer->feed();
                
            } catch (Exception $e) {
                return redirect()->route('kasirindex')->with('error','Kesalahan Sistem');
            } finally {
                $printer->close();
            }
        }
    }

    public function rincian($id){
        date_default_timezone_set('Asia/Jakarta');
        $bulan = date("Y-m", time());
        $time = strtotime($bulan);
        $bulan = date("Y-m", strtotime("-1 month", $time));

        $dataset = Tagihan::where([['id_tempat',$id],['stt_lunas',0],['bln_pakai','!=',$bulan]])
        ->select(
            DB::raw('SUM(sel_tagihan) as tunggakan'),
            DB::raw('SUM(den_tagihan) as denda'))
        ->get();

        $tunggakan = number_format($dataset[0]->tunggakan);
        $denda = number_format($dataset[0]->denda);
        
        
        $dataset = Tagihan::where([['id_tempat',$id],['stt_lunas',0],['bln_pakai','!=',$bulan]])
        ->select(
            'sel_listrik',
            'sel_airbersih',
            'sel_keamananipk',
            'sel_kebersihan',
            'sel_airkotor',
            'sel_lain',
        )
        ->first();

        $listrik = number_format($dataset->sel_listrik);
        $airbersih = number_format($dataset->sel_airbersih);
        $keamananipk = number_format($dataset->sel_keamananipk);
        $kebersihan = number_format($dataset->sel_kebersihan);
        $airkotor = number_format($dataset->sel_airkotor);
        $lain = number_format($dataset->sel_lain);

        $dataset = Tagihan::where([['id_tempat',$id],['stt_lunas',0]])
        ->select(DB::raw('SUM(sel_tagihan) as total'))
        ->get();

        $total = number_format($dataset[0]->total);

        return json_encode(array(
            "id"=>$id,
            "tagihanListrik"=>$listrik,
            "tagihanAirBersih"=>$airbersih,
            "tagihanKeamananIpk"=>$keamananipk,
            "tagihanKebersihan"=>$kebersihan,
            "tagihanAirKotor"=>$airkotor,
            "tagihanLain"=>$lain,
            "tagihanTunggakan"=>$tunggakan,
            "tagihanDenda"=>$denda,
            "tagihanTotal"=>$total,
        ));
    }

    public function bayarStore(Request $request){
        $id = $request->get('tempatId');
        // $dataset = Tagihan::where('id_tempat')->get();
        
        return redirect()->route('kasirindex')->with('success','Tagihan Dibayar');
    }

    public function cari(Request $request){
        echo $request->get('kode');
    }

    public function penerimaan(){
        $connector = new WindowsPrintConnector('EPSONLQ');
                
        $printer = new Printer($connector);
        $pdf = Storage::url('qrcode.pdf');

        $pages = ImagickEscposImage::loadPdf($pdf);
        foreach ($pages as $page) {
            $printer -> graphics($page);
        }
        $printer->close();
    }

    public function scan($id){
        echo $id;
    }
}
