<?php
$role = Session::get('role');
?>


<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<title>Tagihan Pedagang | BP3C</title>
<div class = "container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <?php echo $__env->yieldContent('title'); ?>
            <div>
                <a 
                    href="<?php echo e(url('tagihan/listrik')); ?>"
                    type="submit"
                    class="btn btn-sm btn-warning"><b>
                    <i class="fas fa-fw fa-plus fa-sm text-white-50"></i> Listrik </b> <span class="badge badge-pill badge-light"><?php echo e($listrikBadge); ?></span>
                </a>
                &nbsp;
                <a 
                    href="<?php echo e(url('tagihan/airbersih')); ?>"  
                    type="submit"
                    class="btn btn-sm btn-info"><b>
                    <i class="fas fa-fw fa-plus fa-sm text-white-50"></i> Air Bersih </b> <span class="badge badge-pill badge-light"><?php echo e($airBersihBadge); ?></span>
                </a>
                &nbsp;
                <a 
                    href="#" 
                    data-toggle="modal"
                    data-target="#myPublish" 
                    type="submit" 
                    class="btn btn-sm btn-danger"><b>
                    <i class="fas fa-fw fa-paper-plane fa-sm text-white-50"></i> Publish</b>
                </a>
                &nbsp;
                <div class="dropdown no-arrow" style="display:inline-block">
                    <a 
                        class="dropdown-toggle btn btn-sm btn-success" 
                        href="#" 
                        role="button" 
                        data-toggle="dropdown"
                        aria-haspopup="true" 
                        aria-expanded="false"><b>
                        Menu
                        <i class="fas fa-ellipsis-v fa-sm fa-fw"></i></b>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                        <div class="dropdown-header">Preview Tagihan:</div>
                        <a 
                            class="dropdown-item" 
                            href="<?php echo e(url('rekap/pemakaian',['listrik',$bulanPakai])); ?>"
                            target="_blank"
                            type="submit">
                            <i class="fas fa-fw fa-bolt fa-sm text-gray-500"></i> Listrik
                        </a>
                        <a 
                            class="dropdown-item" 
                            href="<?php echo e(url('rekap/pemakaian',['airbersih',$bulanPakai])); ?>"
                            target="_blank"
                            type="submit">
                            <i class="fas fa-fw fa-tint fa-sm text-gray-500"></i> Air Bersih
                        </a>
                        <a 
                            class="dropdown-item" 
                            href="<?php echo e(url('rekap/pemakaian',['keamananipk',$bulanPakai])); ?>"
                            target="_blank"
                            type="submit">
                            <i class="fas fa-fw fa-lock fa-sm text-gray-500"></i> Keamanan IPK
                        </a>
                        <a 
                            class="dropdown-item" 
                            href="<?php echo e(url('rekap/pemakaian',['kebersihan',$bulanPakai])); ?>"
                            target="_blank"
                            type="submit">
                            <i class="fas fa-fw fa-leaf fa-sm text-gray-500"></i> Kebersihan
                        </a>
                        <a 
                            class="dropdown-item" 
                            href="<?php echo e(url('rekap/pemakaian',['airkotor',$bulanPakai])); ?>"
                            target="_blank"
                            type="submit">
                            <i class="fas fa-fw fa-fill-drip fa-sm text-gray-500"></i> Air Kotor
                        </a>
                        <a 
                            class="dropdown-item" 
                            href="<?php echo e(url('rekap/pemakaian',['lain',$bulanPakai])); ?>"
                            target="_blank"
                            type="submit">
                            <i class="fas fa-fw fa-credit-card fa-sm text-gray-500"></i> Lain - Lain
                        </a>
                        <div class="dropdown-divider"></div>
                        <div class="dropdown-header">Periode:</div>
                        <a 
                            class="dropdown-item" 
                            href="#"
                            data-toggle="modal" 
                            data-target="#myModal" 
                            type="submit">
                            <i class="fas fa-fw fa-search fa-sm text-gray-500"></i> Cari Tagihan
                        </a>
                        <div class="dropdown-divider"></div>
                        <div class="dropdown-header">Edaran:</div>
                        <a 
                            class="dropdown-item" 
                            href="#" 
                            data-toggle="modal" 
                            data-target="#myEdaran" 
                            type="submit">
                            <i class="fas fa-fw fa-print fa-sm text-gray-500"></i> Print Edaran
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
        <?php echo $__env->yieldContent('body'); ?>

        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Tambah Content pada Body modal -->
<div
    class="modal fade"
    id="myPublish"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Publish Tagihan <?php echo e($bulan); ?> ?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body-short">
                <div class="text-center">
                    <i class="fas fa-exclamation-triangle" style="color:#f6c23e;"></i>
                    <br>Pastikan Tagihan benar, sebelum melakukan 
                    <b><i class="fas fa-fw fa-paper-plane fa-sm" style="color:#e74a3b;"></i><span style="color:#e74a3b;">Publish</span></b>. 
                    <br>Lakukan <b>preview</b> pada opsi <b><span style="color:#1cc88a;">Menu</span><i class="fas fa-ellipsis-v fa-sm fa-fw" style="color:#1cc88a;"></i></b>
                    <br>Tagihan yang telah di-publish <b>tidak dapat diedit</b>.
                </div> 
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" type="submit" href="<?php echo e(url('tagihan/publish/now')); ?>">Publish</a>
            </div>
        </div>
    </div>
</div>

<div
    class="modal fade"
    id="myModal"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Bulan Tagihan</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form class="user" action="<?php echo e(url('tagihan/index/periode')); ?>" method="GET">
                <div class="modal-body-short">
                    <div class="form-group">
                        <label for="bulan">Bulan</label>
                        <select class="form-control" name="bulan" id="bulan">
                            <option selected="selected" hidden="hidden" value="<?php echo e($month); ?>">Pilih Bulan</option>
                            <option value="01">Januari</option>
                            <option value="02">Februari</option>
                            <option value="03">Maret</option>
                            <option value="04">April</option>
                            <option value="05">Mei</option>
                            <option value="06">Juni</option>
                            <option value="07">Juli</option>
                            <option value="08">Agustus</option>
                            <option value="09">September</option>
                            <option value="10">Oktober</option>
                            <option value="11">November</option>
                            <option value="12">Desember</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tahun">Tahun</label>
                        <select class="form-control" name="tahun" id="tahun">
                            <option selected="selected" hidden="hidden"  value="<?php echo e($tahun); ?>"><?php echo e($tahun); ?></option>
                            <?php $__currentLoopData = $dataTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($d->thn_tagihan); ?>"><?php echo e($d->thn_tagihan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div
    class="modal fade"
    id="myEdaran"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Print Edaran</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form>
                <div class="modal-body-short">
                    <div class="form-group">
                        <label for="blok">BLOK</label>
                        <select class="form-control" name="blok" id="blok" required>
                            <option selected="selected" hidden="hidden"  value="">Pilih Blok</option>
                            <?php $__currentLoopData = $blok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->nama); ?>"><?php echo e($b->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="cetakEdaran" class="btn btn-primary btn-sm">Cetak</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<script src="<?php echo e(asset('js/tagihan.js')); ?>"></script>
<?php echo $__env->yieldContent('jstable'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( $role == 'master' ? 'layout.master' : 'layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/tagihan/index.blade.php ENDPATH**/ ?>