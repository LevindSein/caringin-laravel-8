<?php
$pengguna = 0;
$daya = 0;
$pakai = 0;
$beban = 0;
$bpju = 0;
$tagihan = 0;
$realisasi = 0;
$selisih = 0;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Pemakaian Listrik | BP3C</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/style-pemakaian.css')); ?>" media="all"/>
        <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
    </head>
    <body onload="window.print()">
        <?php for($i=1;$i<=2;$i++): ?>
        <?php if($i == 1): ?>
        <h2 style="text-align:center;">REKAP PEMAKAIAN LISTRIK<br><?php echo e($bln); ?></h2>
        <main>
            <table class="tg">
                <tr>
                    <th class="tg-r8fv">No.</th>
                    <th class="tg-r8fv">Blok</th>
                    <th class="tg-r8fv">Pengguna</th>
                    <th class="tg-r8fv">Daya</th>
                    <th class="tg-r8fv">Pakai</th>
                    <th class="tg-r8fv">Beban</th>
                    <th class="tg-r8fv">BPJU</th>
                    <th class="tg-r8fv">Tagihan</th>
                    <th class="tg-r8fv">Realisasi</th>
                    <th class="tg-r8fv">Selisih</th>
                </tr>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="tg-cegc"><?php echo e($no); ?></td>
                    <td class="tg-cegc"><?php echo e($d->blok); ?></td>
                    <td class="tg-cegc"><?php echo e($d->pengguna); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->daya)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->pakai)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->beban)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->bpju)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->tagihan)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->realisasi)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->selisih)); ?></td>
                </tr>
                <?php $no++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="tg-vbo4" style="text-align:center;" colspan="2">Total</td>
                    <td class="tg-vbo4" style="text-align:center;"><?php echo e(number_format($ttlRekap[0])); ?></td>
                    <td class="tg-8m6k"><?php echo e(number_format($ttlRekap[1])); ?> W</td>
                    <td class="tg-8m6k"><?php echo e(number_format($ttlRekap[2])); ?> kWh</td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[3])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[4])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[5])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[6])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[7])); ?></td>
                </tr>
            </table>
        </main>
        <?php else: ?>
        <h2 style="text-align:center;page-break-before:always">RINCIAN PEMAKAIAN LISTRIK<br><?php echo e($bln); ?></h2>
        <?php $__currentLoopData = $rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <br>
            <h3><?php echo e($data[0]); ?></h3>
            <main>
                <table class="tg">
                    <tr>
                        <th class="tg-r8fv">No.</th>
                        <th class="tg-r8fv">Kontrol</th>
                        <th class="tg-r8fv">Pengguna</th>
                        <th class="tg-r8fv">Daya</th>
                        <th class="tg-r8fv">M.Lalu</th>
                        <th class="tg-r8fv">M.Baru</th>
                        <th class="tg-r8fv">Pakai</th>
                        <th class="tg-r8fv">Rek.Min</th>
                        <th class="tg-r8fv">B.Blok1</th>
                        <th class="tg-r8fv">B.Blok2</th>
                        <th class="tg-r8fv">B.Beban</th>
                        <th class="tg-r8fv">BPJU</th>
                        <th class="tg-r8fv">Tagihan</th>
                        <th class="tg-r8fv">Realisasi</th>
                        <th class="tg-r8fv">Selisih</th>
                    </tr>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $data[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="tg-cegc"><?php echo e($no); ?></td>
                        <td class="tg-cegc"><?php echo e($d->kontrol); ?></td>
                        <td class="tg-g25h" style="text-align:left;"><?php echo e($d->pengguna); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->daya)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->lalu)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->baru)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->pakai)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->rekmin)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->blok1)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->blok2)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->beban)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->bpju)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->tagihan)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->realisasi)); ?></td>
                        <td class="tg-g25h"><?php echo e(number_format($d->selisih)); ?></td>
                    </tr>
                    <?php $no++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $data[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="tg-vbo4" style="text-align:center;" colspan="3">Total</td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->daya)); ?></td>
                        <td class="tg-8m6k" colspan="2"></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->pakai)); ?></td>
                        <td class="tg-8m6k" colspan="3"></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->beban)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->bpju)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->tagihan)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->realisasi)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->selisih)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </main>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endfor; ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/pemakaian/listrik.blade.php ENDPATH**/ ?>