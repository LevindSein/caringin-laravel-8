<?php
date_default_timezone_set('Asia/Jakarta');
$sekarang = date("d-m-Y H:i:s",time());
?>


<?php $__env->startSection('body'); ?>
<?php $__env->startSection('title'); ?>
<h6 class="m-0 font-weight-bold text-primary">Tagihan Periode <?php echo e($bulan); ?></h6>
<?php $__env->stopSection(); ?>
<div class="table-responsive ">
    <table
        class="table"
        id="tableTagihan"
        width="100%"
        cellspacing="0"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th rowspan="2">Kontrol</th>
                <th rowspan="2">Pengguna</th>
                <th colspan="4" class="listrik">Listrik</th>
                <th colspan="3" class="air">Air</th>
                <th rowspan="2" class="keamanan">Keamanan IPK (Rp.)</th>
                <th rowspan="2" class="kebersihan">Kebersihan (Rp.)</th>
                <th rowspan="2" style="background-color:rgba(50, 255, 255, 0.2);">Air Kotor (Rp.)</th>
                <th rowspan="2" style="background-color:rgba(255, 50, 255, 0.2);">Lain - Lain (Rp.)</th>
                <th rowspan="2" style="background-color:rgba(255, 212, 71, 0.2);">Jumlah (Rp.)</th>
                <th rowspan="2">Action</th>
            </tr>
            <tr>
                <th class="listrik-hover">Daya</th>
                <th class="listrik-hover">Lalu</th>
                <th class="listrik-hover">Baru</th>
                <th class="listrik-hover">Total (Rp.)</th>
                <th class="air-hover">Lalu</th>
                <th class="air-hover">Baru</th>
                <th class="air-hover">Total (Rp.)</th>
            </tr>
        </thead>
        <tbody class="table-bordered">
            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($d->kd_kontrol); ?></td>
                <td class="text-left"><?php echo e($d->pengguna); ?></td>
                <td><?php echo e(number_format($d->daya_listrik)); ?></td>
                <td><?php echo e(number_format($d->awal_listrik)); ?></td>
                <td><?php echo e(number_format($d->akhir_listrik)); ?></td>
                <td><?php echo e(number_format($d->sel_listrik)); ?></td>
                <td><?php echo e(number_format($d->awal_airbersih)); ?></td>
                <td><?php echo e(number_format($d->akhir_airbersih)); ?></td>
                <td><?php echo e(number_format($d->sel_airbersih)); ?></td>
                <td><?php echo e(number_format($d->sel_keamananipk)); ?></td>
                <td><?php echo e(number_format($d->sel_kebersihan)); ?></td>
                <td><?php echo e(number_format($d->sel_airkotor)); ?></td>
                <td><?php echo e(number_format($d->sel_lain)); ?></td>
                <td><?php echo e(number_format($d->sel_tagihan)); ?></td>
                <td class="text-center">
                    <a
                        href="<?php echo e(url('tagihan/update',[$d->id])); ?>"
                        title="Edit">
                        <i class="fas fa-edit fa-sm"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jstable'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableTagihan'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "dom": "r<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>><'row'<'col-sm-12'tr>><'" +
                    "row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            "buttons": [
                {
                    text: '<i class="fas fa-file-excel fa-lg"></i>',
                    extend: 'excel',
                    className: 'btn btn-success bg-gradient-success',
                    title: 'Tagihan Periode <?php echo e($bulan); ?> <?php echo e($sekarang); ?>',
                    exportOptions: {
                        columns: [0,1,2,3,4,5,6,7,8,9,10,11,12,13]
                    },
                    titleAttr: 'Download Excel'
                }
            ],
            "scrollX": true,
            "scrollCollapse": true,
            "deferRender": true,
            "fixedColumns":   {
                "leftColumns": 2,
                "rightColumns": 2,
            },
            "pageLength": 8,
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [14] }
            ],
            "order": [ 0, "asc" ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tagihan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/tagihan/data.blade.php ENDPATH**/ ?>