<html>
<body>

<img src="<?php echo e(asset($pdf)); ?>" alt="Girl in a jacket" width="200" height="200">

</body>
</html><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/kasir/print.blade.php ENDPATH**/ ?>