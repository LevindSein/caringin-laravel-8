<?php
    echo "<script>window.close();</script>";
?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/kasir/print.blade.php ENDPATH**/ ?>