<?php
date_default_timezone_set('Asia/Jakarta');
$sekarang = date("d-m-Y H:i:s",time());
?>


<?php $__env->startSection('body'); ?>
<title>Data Tempat Usaha | BP3C</title>
<?php $__env->startSection('title'); ?>
<h6 class="m-0 font-weight-bold text-primary">Data Tempat Usaha</h6>
<?php $__env->stopSection(); ?>
<div class="table-responsive ">
    <table
        class="table"
        id="tableTempat"
        width="100%"
        cellspacing="0"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th rowspan="2">Kontrol</th>
                <th rowspan="2">Lokasi</th>
                <th rowspan="2">Pengguna</th>
                <th rowspan="2">No.Los</th>
                <th rowspan="2">Jml.Los</th>
                <th rowspan="2">Usaha</th>
                <th colspan="2">Listrik</th>
                <th colspan="2">Air Bersih</th>
                <th colspan="2">Keamanan & IPK</th>
                <th colspan="2">Kebersihan</th>
                <th rowspan="2">Air Kotor</th>
                <th rowspan="2">Lain - Lain</th>
                <th rowspan="2">Status</th>
                <th rowspan="2">Ket</th>
                <th rowspan="2">Pemilik</th>
                <th rowspan="2">Tagihan</th>
                <th rowspan="2">Action</th>
            </tr>
            <tr>
                <th>Meteran</th>
                <th>Bebas Bayar</th>
                <th>Meteran</th>
                <th>Bebas Bayar</th>
                <th>Tarif</th>
                <th>Diskon</th>
                <th>Tarif</th>
                <th>Diskon</th>
            </tr>
        </thead>
        
        <tbody class="table-bordered">
            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center" style="<?php echo e(($data->stt_cicil == 0) ? 'color:green;' : 'color:orange;'); ?>"><?php echo e($data->kd_kontrol); ?></td>
                <td class="text-center"><?php if($data->lok_tempat == NULL): ?> &mdash; <?php else: ?> <?php echo e($data->lok_tempat); ?> <?php endif; ?></td>
                <td class="text-left"><?php echo e($data->pengguna); ?></td>
                <td class="text-center" style="white-space:normal;"><?php echo e($data->no_alamat); ?></td>
                <td class="text-center"><?php echo e($data->jml_alamat); ?></td>
                <td class="text-center"><?php echo e($data->bentuk_usaha); ?></td>
                <td class="text-center"><?php if($data->trf_listrik == NULL): ?> <i class="fas fa-times"></i> <?php else: ?> <?php echo e($data->listrik); ?> <?php endif; ?></td>
                <td class="text-center"><?php if($data->dis_listrik == 0): ?> <i class="fas fa-times"></i> <?php else: ?> <i class="fas fa-check"></i> <?php endif; ?></td>
                <td class="text-center"><?php if($data->trf_airbersih == NULL): ?> <i class="fas fa-times"></i> <?php else: ?> <?php echo e($data->air); ?> <?php endif; ?></td>
                <td class="text-center"><?php if($data->dis_airbersih == 0): ?> <i class="fas fa-times"></i> <?php else: ?> <i class="fas fa-check"></i> <?php endif; ?></td>
                <td class="text-center"><?php if($data->trf_keamananipk == NULL): ?> <i class="fas fa-times"></i> <?php else: ?> <?php echo e(number_format($data->keamananipk)); ?> <?php endif; ?></td>
                <td class="text-center"><?php if($data->dis_keamananipk == 0): ?> <i class="fas fa-times"></i> <?php else: ?> <i class="fas fa-check"></i> <?php endif; ?></td>
                <td class="text-center"><?php if($data->trf_kebersihan == NULL): ?> <i class="fas fa-times"></i> <?php else: ?> <?php echo e(number_format($data->kebersihan)); ?> <?php endif; ?></td>
                <td class="text-center"><?php if($data->dis_kebersihan == 0): ?> <i class="fas fa-times"></i> <?php else: ?> <i class="fas fa-check"></i> <?php endif; ?></td>
                <td class="text-center"><?php if($data->trf_airkotor == NULL): ?> <i class="fas fa-times"></i> <?php else: ?> <?php echo e(number_format($data->airkotor)); ?> <?php endif; ?></td>
                <td class="text-center"><?php if($data->trf_lain == NULL): ?> <i class="fas fa-times"></i> <?php else: ?> <?php echo e(number_format($data->lain)); ?> <?php endif; ?></td>
                <td class="text-center"><?php if($data->stt_tempat == 1): ?> &#10004; <?php else: ?> &#10060; <?php endif; ?></td>
                <td class="text-center"><?php if($data->stt_tempat == 1): ?> Aktif <?php else: ?> <?php echo e($data->ket_tempat); ?> <?php endif; ?></td>
                <td class="text-left"><?php echo e($data->pemilik); ?></td>
                <td class="text-center">
                    <a
                        href="<?php echo e(url('tempatusaha/details',[$data->id])); ?>"
                        type="submit" 
                        class="btn btn-sm btn-primary">Details</a>
                </td>
                <td class="text-center">
                    <a
                        href="<?php echo e(url('tempatusaha/update',[$data->id])); ?>"
                        title="Edit">
                        <i class="fas fa-edit fa-sm"></i></a>
                    &nbsp;
                    <a
                        href="<?php echo e(url('tempatusaha/delete',[$data->id])); ?>"
                        title="Hapus">
                        <i class="fas fa-trash-alt" style="color:#e74a3b;"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jstable'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableTempat'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "dom": "r<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>><'row'<'col-sm-12'tr>><'" +
                    "row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            "buttons": [
                {
                    text: '<i class="fas fa-file-excel fa-lg"></i>',
                    extend: 'excel',
                    className: 'btn btn-success bg-gradient-success',
                    title: 'Data Tempat Usaha <?php echo e($sekarang); ?>',
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
                    },
                    titleAttr: 'Download Excel'
                }
            ],
            "fixedColumns":   {
                "leftColumns": 3,
                "rightColumns": 2,
            },
            "scrollX": true,
            "scrollCollapse": true,
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [19,20] }
            ],
            "pageLength": 8,
            "order": [ 0, "asc" ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tempat.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/tempat/data.blade.php ENDPATH**/ ?>