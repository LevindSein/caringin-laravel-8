<?php $__env->startSection('title', __('Coming Soon')); ?>
<?php $__env->startSection('code', '痛い'); ?>
<?php $__env->startSection('message', __('Under Construction')); ?>
<?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/page/cmp.blade.php ENDPATH**/ ?>