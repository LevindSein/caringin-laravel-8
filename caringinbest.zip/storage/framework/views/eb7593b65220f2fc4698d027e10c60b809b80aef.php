<?php
$role = Session::get('role');

date_default_timezone_set('Asia/Jakarta');
$sekarang = date("d-m-Y H:i:s",time());
?>


<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<title>Laporan Pendapatan | BP3C</title>
<div class = "container-fluid">
    <ul class="tabs-animated-shadow tabs-animated nav">
        <li class="nav-item">
            <a role="tab" class="nav-link active" id="tab-c-0" data-toggle="tab" href="#tab-animated-0">
                <span>Harian</span>
            </a>
        </li>
        <li class="nav-item">
            <a role="tab" class="nav-link" id="tab-c-1" data-toggle="tab" href="#tab-animated-1">
                <span>Bulanan</span>
            </a>
        </li>
        <li class="nav-item">
            <a role="tab" class="nav-link" id="tab-c-2" data-toggle="tab" href="#tab-animated-2">
                <span>Tahunan</span>
            </a>
        </li>
    </ul>
</div>
<div class = "container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Laporan Pendapatan</h6>
        </div>
        <div class="card-body">
            
            <div class="tab-content">
                <div class="tab-pane active" id="tab-animated-0" role="tabpanel">
                    <?php echo $__env->make('pendapatan.harian', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane" id="tab-animated-1" role="tabpanel">
                    <?php echo $__env->make('pendapatan.bulanan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane" id="tab-animated-2" role="tabpanel">
                    <?php echo $__env->make('pendapatan.tahunan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Tambah Content pada Body modal -->
<div
    class="modal fade"
    id="modalHarian"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cari Pendapatan Harian by Range</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form class="user" action="<?php echo e(url('data/harian')); ?>" method="POST">
                <div class="modal-body-short">
                    <?php echo csrf_field(); ?>
                    <div class="form-group col-lg-12">
                        <label for="dari">Dari</label>
                        <input
                            required
                            autocomplete="off"
                            type="date"
                            name="dari"
                            class="form-control"
                            id="dari">
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="sampai">Sampai</label>
                        <input
                            required
                            autocomplete="off"
                            type="date"
                            name="sampai"
                            class="form-control"
                            id="sampai">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div
    class="modal fade"
    id="modalBulanan"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cari Pendapatan Bulanan by Range</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form class="user" action="<?php echo e(url('data/bulanan')); ?>" method="POST">
                <div class="modal-body-short">
                    <?php echo csrf_field(); ?>
                    <div class="form-group col-lg-12">
                        <label>Dari</label>
                        <div class="input-group">
                            <select class="form-control" name="dariBulan" id="dariBulan" required>
                                <option disabled="disabled" selected="selected" hidden="hidden" value="">Pilih Bulan</option>
                            </select>
                            <select class="form-control" name="dariTahun" id="dariTahun" required>
                                <option disabled="disabled" selected="selected" hidden="hidden" value="">Pilih Tahun</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group col-lg-12">
                        <label>Sampai</label>
                        <div class="input-group">
                            <select class="form-control" name="sampaiBulan" id="sampaiBulan" required>
                                <option disabled="disabled" selected="selected" hidden="hidden" value="">Pilih Bulan</option>
                            </select>
                            <select class="form-control" name="sampaiTahun" id="sampaiTahun" required>
                                <option disabled="disabled" selected="selected" hidden="hidden" value="">Pilih Tahun</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div
    class="modal fade"
    id="modalTahunan"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cari Pendapatan Tahunan by Range</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form class="user" action="<?php echo e(url('data/tahunan')); ?>" method="POST">
                <div class="modal-body-short">
                    <?php echo csrf_field(); ?>
                    <div class="form-group col-lg-12">
                        <label>Dari</label>
                        <div class="form-group">
                            <select class="form-control" name="dari" id="dari" required>
                                <option disabled="disabled" selected="selected" hidden="hidden" value="">Pilih Tahun</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group col-lg-12">
                        <label>Sampai</label>
                        <div class="form-group">
                            <select class="form-control" name="sampai" id="sampai" required>
                                <option disabled="disabled" selected="selected" hidden="hidden" value="">Pilih Tahun</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( $role == 'master' ? 'layout.master' : 'layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/pendapatan/index.blade.php ENDPATH**/ ?>