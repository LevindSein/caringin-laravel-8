<div class="table-responsive">
    <table 
        class="table table-bordered" 
        id="userAdmin"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead>
            <tr>
                <th>No.</th>
                <th>Username</th>
                <th>Nama</th>
                <th>KTP</th>
                <th>HP</th>
                <th>Email</th>
                <th>Otoritas</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $i= 1; ?>
            <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($i); ?></td>
                <td class="text-center"><?php echo e($data->username); ?></td>
                <td class="text-center"><?php echo e($data->nama); ?></td>
                <td class="text-center"><?php echo e($data->ktp); ?></td>
                <td class="text-center"><?php echo e($data->hp); ?></td>
                <td class="text-center"><?php echo e($data->email); ?></td>
                <td class="text-center">
                <?php if($data->otoritas != NULL): ?>
                    <i class="fas fa-check"></i>
                <?php else: ?>
                    <i class="fas fa-times"></i>
                <?php endif; ?>
                </td>
                <td class="text-center">
                    <a
                        href="<?php echo e(url('user/otoritas',[$data->id])); ?>"
                        title="Otoritas">
                        <i class="fas fa-hands-helping" style="color:#1cc88a;"></i></a>
                    &nbsp;
                    <a
                        href="<?php echo e(url('user/reset',[$data->id])); ?>"
                        title="Reset Password">
                        <i class="fas fa-key fa-sm" style="color:orange;"></i></a>
                    &nbsp;
                    <a
                        href="<?php echo e(url('user/update',[$data->id])); ?>"
                        title="Update">
                        <i class="fas fa-edit fa-sm"></i></a>
                    &nbsp;
                    <a
                        href="<?php echo e(url('user/delete',[$data->id])); ?>"
                        title="Hapus">
                        <i class="fas fa-trash-alt" style="color:#e74a3b;"></i></a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<script>
    $(document).ready(function () {
        $(
            '#userAdmin'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "scrollX": true,
            "bSortable": false,
            "deferRender": true,
            "dom": "r<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>><'row'<'col-sm-12'tr>><'" +
                    "row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",

            "buttons": [
                {
                    text: '<i class="fas fa-file-excel fa-lg"></i>',
                    extend: 'excel',
                    className: 'btn btn-success bg-gradient-success',
                    title: 'Data Admin <?php echo e($sekarang); ?>',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5]
                    },
                    titleAttr: 'Download Excel'
                }
            ],
            "fixedColumns":   {
                "leftColumns": 3,
                "rightColumns": 1,
            },
        });
    });
</script><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/user/admin.blade.php ENDPATH**/ ?>