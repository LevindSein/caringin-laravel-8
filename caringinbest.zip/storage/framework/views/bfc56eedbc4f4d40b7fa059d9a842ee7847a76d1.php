

<?php $__env->startSection('title', __('Coming Soon')); ?>
<?php $__env->startSection('code', $id); ?>
<?php $__env->startSection('message', __('Under Construction')); ?>

<?php echo $__env->make('errors.minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/errors/cmp.blade.php ENDPATH**/ ?>