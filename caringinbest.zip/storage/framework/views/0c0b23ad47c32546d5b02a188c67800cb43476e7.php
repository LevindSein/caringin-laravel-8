<div class="table-responsive">
    <table 
        class="table table-bordered" 
        id="alat_listrik"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead>
            <tr>
                <th>No.</th>
                <th>Kode</th>
                <th>Nomor</th>
                <th>Stand</th>
                <th>Daya</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $i= 1; ?>
            <?php $__currentLoopData = $listrik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
            $kontrol = DB::table('tempat_usaha')
            ->where('tempat_usaha.id_meteran_listrik',$data->id)
            ->select('kd_kontrol')
            ->first();
            
            if($kontrol == NULL){
                $kontrol = 'idle';
            }
            else{
                $kontrol = $kontrol->kd_kontrol;
            }
            ?>
            <tr>
                <td class="text-center"><?php echo e($i); ?></td>
                <td><?php echo e($data->kode); ?></td>
                <td><?php echo e($data->nomor); ?></td>
                <td><?php echo e(number_format($data->akhir)); ?></td>
                <td><?php echo e(number_format($data->daya)); ?></td>
                <td class="text-center" style="<?php echo e(($kontrol == 'idle') ? 'color:green;' : ''); ?>" ><?php echo e($kontrol); ?></td>
                <td class="text-center">
                    <a
                        href="<?php echo e(url('utilities/meteran/qr',['listrik',$data->id])); ?>"
                        title="Print QR">
                        <i class="fas fa-qrcode"></i></a>
                    &nbsp;
                    <a
                        href="<?php echo e(url('utilities/meteran/delete',['listrik',$data->id])); ?>"
                        title="Hapus">
                        <i class="fas fa-trash-alt" style="color:#e74a3b;"></i></a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<script>
    $(document).ready(function () {
        $(
            '#alat_listrik'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "scrollX": true,
            "bSortable": false,
            "deferRender": true,
            "dom": "r<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>><'row'<'col-sm-12'tr>><'" +
                    "row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",

            "buttons": [
                {
                    text: '<i class="fas fa-file-excel fa-lg"></i>',
                    extend: 'excel',
                    className: 'btn btn-success bg-gradient-success',
                    title: 'Daftar Alat Listrik <?php echo e($sekarang); ?>',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4]
                    },
                    titleAttr: 'Download Excel'
                }
            ]
        });
    });
</script><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/meteran/listrik.blade.php ENDPATH**/ ?>