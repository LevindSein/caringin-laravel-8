<?php
$role = Session::get('role');
?>


<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<title>Details Pedagang | BP3C</title>
<div class = "container-fluid">
    <div class="d-sm-flex align-items-center justify-content-center">
        <h3 class="h3 mb-4 text-primary"><b><?php echo e($nama); ?></b></h3>
    </div>
    <div class="mb-4">
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="card shadow col-lg-6">
                    <div class="p-4">
                        <div class="form-group col-lg-12">
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <label>Alamat</label>
                                <label>Tagihan</label>
                            </div>
                            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="input-group">
                                <?php $id = $d[2] ?>
                                <button 
                                    onclick="location.href='<?php echo e(url('tempatusaha/details',[$id])); ?>'"
                                    class="form-control"
                                    aria-describedby="inputGroupPrepend"
                                    style="text-align:left;"><?php echo e($d[0]); ?>

                                </button>
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupPrepend">Rp. <?php echo e(number_format($d[1])); ?></span>
                                </div>
                            </div><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group col-lg-12">
                                <a href="<?php echo e(url('pedagang/data')); ?>" type="button" class="btn btn-primary btn-user btn-block">OK</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Tambah Content pada Body modal -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( $role == 'master' ? 'layout.master' : 'layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinbest\resources\views/pedagang/details.blade.php ENDPATH**/ ?>