<?php
var_dump($dataset);
?>