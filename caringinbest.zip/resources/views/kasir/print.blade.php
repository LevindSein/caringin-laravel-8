<html>
<body>

<img src="{{asset($pdf)}}" alt="Girl in a jacket" width="200" height="200">

</body>
</html>