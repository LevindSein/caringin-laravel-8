@extends('errors.minimal')

@section('title', __('Coming Soon'))
@section('code', $id)
@section('message', __('Under Construction'))
