<?php
$role = Session::get('role');

function bln_indo($bln){
    $bulan = array (
        1 =>   'Jan',
        'Feb',
        'Mar',
        'Apr',
        'Mei',
        'Jun',
        'Jul',
        'Agu',
        'Sep',
        'Okt',
        'Nov',
        'Des'
    );
    $explode = explode('-', $bln);
    return $bulan[ (int)$explode[1] ] . ' ' . $explode[0];
}
?>


<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<title>Details Tagihan Tempat Usaha | BP3C</title>
<div class = "container-fluid">
    <div class="d-sm-flex align-items-center justify-content-center">
        <h3 class="h3 mb-4 text-primary"><b><?php echo e($nama); ?></b></h3>
    </div>
    <div class="mb-4">
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="card shadow col-lg-6">
                    <div class="p-4">
                        <div class="form-group col-lg-12">
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <label>Bulan</label>
                                <label>Tagihan</label>
                            </div>
                            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="input-group">
                                <input readonly type="text" value="<?php echo e(bln_indo($d->bln_tagihan)); ?>" class="form-control" name="bulan" id="bulan" aria-describedby="inputGroupPrepend">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupPrepend">Rp. <?php echo e(number_format($d->sel_tagihan)); ?></span>
                                </div>
                            </div><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group col-lg-12">
                                <a href="<?php echo e(url('tempatusaha/data')); ?>" type="button" class="btn btn-primary btn-user btn-block">OK</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Tambah Content pada Body modal -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( $role == 'master' ? 'layout.master' : 'layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\CaringinBest\resources\views/tempat/details.blade.php ENDPATH**/ ?>