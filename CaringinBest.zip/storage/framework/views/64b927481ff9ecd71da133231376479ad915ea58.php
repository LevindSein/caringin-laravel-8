<?php if($message = Session::get('successUpd')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button> 
    <strong>Sukses ! </strong><?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('errorUpd')): ?>
<div class="alert alert-danger alert-block"> 
    <button type="button" class="close" data-dismiss="alert">×</button> 
    <strong>Maaf ! </strong><?php echo e($message); ?> 
</div>
<?php endif; ?>


<?php if($message = Session::get('warningUpd')): ?>
<div class="alert alert-warning alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button> 
	<strong>Warning ! </strong> <?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('infoUpd')): ?>
<div class="alert alert-info alert-block">	
    <button type="button" class="close" data-dismiss="alert">×</button> 
	<strong>Info ! </strong><?php echo e($message); ?>

</div>
<?php endif; ?><?php /**PATH D:\UIN\Kerja Praktik\CaringinBest\resources\views/message/update-message.blade.php ENDPATH**/ ?>