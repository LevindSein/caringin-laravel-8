
<?php $__env->startSection('content'); ?>
<title>Dashboard | BP3C</title>
<div class = "container-fluid">
    <div class="row">
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Realisasi Tahun <?php echo e($thn); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="pieRealisasi"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-2">
                            <i class="fas fa-circle text-warning"></i>
                            Listrik
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-primary"></i>
                            Air Bersih
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-info"></i>
                            Keamanan & IPK
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-success"></i>
                            Kebersihan
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Selisih Tahun <?php echo e($thn); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="pieSelisih"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-2">
                            <i class="fas fa-circle text-warning"></i>
                            Listrik
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-primary"></i>
                            Air Bersih
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-info"></i>
                            Keamanan & IPK
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-success"></i>
                            Kebersihan
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Pengguna Fasilitas</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="piePengguna"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-2">
                            <i class="fas fa-circle text-warning"></i>
                            Listrik
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-primary"></i>
                            Air Bersih
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-info"></i>
                            Keamanan & IPK
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-success"></i>
                            Kebersihan
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div class="card shadow mb-4">
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Pendapatan Bulanan Tahun <?php echo e($thn); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-area-new">
                        <canvas id="pendapatanChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Akumulasi Pendapatan Bulanan Tahun <?php echo e($thn); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-area-new">
                        <canvas id="akumulasiChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Status Tempat Usaha <?php echo e(number_format($pengguna)); ?> Unit</h6>
                </div>
                <div class="card-body">
                    <h8 class="font-weight-bold">Aktif
                        <span class="float-right"><?php echo e(number_format($penggunaAktif)); ?>

                            Unit - <?php echo e(($penggunaAktif / $pengguna) * 100); ?>%</span>
                    </h8>
                    <div class="progress mb-4">
                        <div
                            class="progress-bar bg-success"
                            role="progressbar"
                            style="width: <?php echo e(($penggunaAktif / $pengguna) * 100); ?>%"
                            aria-valuenow="20"
                            aria-valuemin="0"
                            aria-valuemax="100"></div>
                    </div>
                    <h8 class="font-weight-bold">Non-Aktif
                        <span class="float-right"><?php echo e(number_format($penggunaNonAktif)); ?>

                            Unit - <?php echo e(($penggunaNonAktif / $pengguna) * 100); ?>%</span>
                    </h8>
                    <div class="progress mb-4">
                        <div
                            class="progress-bar bg-success"
                            role="progressbar"
                            style="width: <?php echo e(($penggunaNonAktif / $pengguna) * 100); ?>%"
                            aria-valuenow="20"
                            aria-valuemin="0"
                            aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Tentang Aplikasi</h6>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <img
                            class="img-fluid px-3 px-sm-4 mt-3 mb-4"
                            style="width: 21rem;"
                            src="../img/undraw_posting_photo.svg"
                            alt=""></div>
                        <p>Aplikasi dikelola oleh PT. Pengelola Pusat Perdagangan Caringin.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    var pendapatanCanvas = document.getElementById("pendapatanChart");
    Chart.defaults.global.defaultFontFamily = 'Nunito',
    '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",' +
            'Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';
    Chart.defaults.global.defaultFontSize = 10;

    var data = {
        labels: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "Mei",
            "Jun",
            "Jul",
            "Agt",
            "Sep",
            "Okt",
            "Nov",
            "Des"
        ],
        datasets: [
            {
                label: "Tagihan",
                backgroundColor: "#4e73df",
                data: [
                    <?php echo e($tagihanJan); ?>,
                    <?php echo e($tagihanFeb); ?>,
                    <?php echo e($tagihanMar); ?>,
                    <?php echo e($tagihanApr); ?>,
                    <?php echo e($tagihanMei); ?>,
                    <?php echo e($tagihanJun); ?>,
                    <?php echo e($tagihanJul); ?>,
                    <?php echo e($tagihanAgu); ?>,
                    <?php echo e($tagihanSep); ?>,
                    <?php echo e($tagihanOkt); ?>,
                    <?php echo e($tagihanNov); ?>,
                    <?php echo e($tagihanDes); ?>

                ]
            }, {
                label: "Realisasi",
                backgroundColor: "#1cc88a",
                data: [
                    <?php echo e($realisasiJan); ?>,
                    <?php echo e($realisasiFeb); ?>,
                    <?php echo e($realisasiMar); ?>,
                    <?php echo e($realisasiApr); ?>,
                    <?php echo e($realisasiMei); ?>,
                    <?php echo e($realisasiJun); ?>,
                    <?php echo e($realisasiJul); ?>,
                    <?php echo e($realisasiAgu); ?>,
                    <?php echo e($realisasiSep); ?>,
                    <?php echo e($realisasiOkt); ?>,
                    <?php echo e($realisasiNov); ?>,
                    <?php echo e($realisasiDes); ?>

                ]
            }, {
                label: "Selisih",
                backgroundColor: "#e74a3b",
                data: [
                    <?php echo e($selisihJan); ?>,
                    <?php echo e($selisihFeb); ?>,
                    <?php echo e($selisihMar); ?>,
                    <?php echo e($selisihApr); ?>,
                    <?php echo e($selisihMei); ?>,
                    <?php echo e($selisihJun); ?>,
                    <?php echo e($selisihJul); ?>,
                    <?php echo e($selisihAgu); ?>,
                    <?php echo e($selisihSep); ?>,
                    <?php echo e($selisihOkt); ?>,
                    <?php echo e($selisihNov); ?>,
                    <?php echo e($selisihDes); ?>

                ]
            }
        ]
    };
    var pendapatanChart = new Chart(pendapatanCanvas, {
        type: 'bar',
        data: data,
        options: {
            tooltips: {
                enabled: true,
                callbacks: {
                    // this callback is used to create the tooltip label
                    label: function (tooltipItem, data) {
                        // get the data label and data value to display convert the data value to local
                        // string so it uses a comma seperated number
                        var dataLabel = data.labels[tooltipItem.index];
                        var value = ': Rp.' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString();

                        // make this isn't a multi-line label (e.g. [["label 1 - line 1, "line 2, ],
                        // [etc...]])
                        if (Chart.helpers.isArray(dataLabel)) {
                            // show value on first line of multiline label need to clone because we are
                            // changing the value
                            dataLabel = dataLabel.slice();
                            dataLabel[0] += value;
                        } else {
                            dataLabel += value;
                        }

                        // return the text to display on the tooltip
                        return dataLabel;
                    }
                }
            },
            barValueSpacing: 20,
            scales: {
                xAxes: [
                    {
                        barPercentage: 1,
                        categoryPercentage: 0.6
                    }
                ],
                yAxes: [
                    {
                        ticks: {
                            min: 0
                        }
                    }
                ]
            }
        }
    });

    var pendapatanCanvas = document.getElementById("akumulasiChart");
    Chart.defaults.global.defaultFontFamily = 'Nunito',
    '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",' +
            'Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';
    Chart.defaults.global.defaultFontSize = 10;

    var data = {
        labels: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "Mei",
            "Jun",
            "Jul",
            "Agt",
            "Sep",
            "Okt",
            "Nov",
            "Des"
        ],
        datasets: [
            {
                label: "Tagihan",
                backgroundColor: "#4e73df",
                data: [
                    <?php echo e($tagihanJanAku); ?>,
                    <?php echo e($tagihanFebAku); ?>,
                    <?php echo e($tagihanMarAku); ?>,
                    <?php echo e($tagihanAprAku); ?>,
                    <?php echo e($tagihanMeiAku); ?>,
                    <?php echo e($tagihanJunAku); ?>,
                    <?php echo e($tagihanJulAku); ?>,
                    <?php echo e($tagihanAguAku); ?>,
                    <?php echo e($tagihanSepAku); ?>,
                    <?php echo e($tagihanOktAku); ?>,
                    <?php echo e($tagihanNovAku); ?>,
                    <?php echo e($tagihanDesAku); ?>

                ]
            }, {
                label: "Realisasi",
                backgroundColor: "#1cc88a",
                data: [
                    <?php echo e($realisasiJanAku); ?>,
                    <?php echo e($realisasiFebAku); ?>,
                    <?php echo e($realisasiMarAku); ?>,
                    <?php echo e($realisasiAprAku); ?>,
                    <?php echo e($realisasiMeiAku); ?>,
                    <?php echo e($realisasiJunAku); ?>,
                    <?php echo e($realisasiJulAku); ?>,
                    <?php echo e($realisasiAguAku); ?>,
                    <?php echo e($realisasiSepAku); ?>,
                    <?php echo e($realisasiOktAku); ?>,
                    <?php echo e($realisasiNovAku); ?>,
                    <?php echo e($realisasiDesAku); ?>

                ]
            }, {
                label: "Selisih",
                backgroundColor: "#e74a3b",
                data: [
                    <?php echo e($selisihJanAku); ?>,
                    <?php echo e($selisihFebAku); ?>,
                    <?php echo e($selisihMarAku); ?>,
                    <?php echo e($selisihAprAku); ?>,
                    <?php echo e($selisihMeiAku); ?>,
                    <?php echo e($selisihJunAku); ?>,
                    <?php echo e($selisihJulAku); ?>,
                    <?php echo e($selisihAguAku); ?>,
                    <?php echo e($selisihSepAku); ?>,
                    <?php echo e($selisihOktAku); ?>,
                    <?php echo e($selisihNovAku); ?>,
                    <?php echo e($selisihDesAku); ?>

                ]
            }
        ]
    };
    var pendapatanChart = new Chart(pendapatanCanvas, {
        type: 'bar',
        data: data,
        options: {
            tooltips: {
                enabled: true,
                callbacks: {
                    // this callback is used to create the tooltip label
                    label: function (tooltipItem, data) {
                        // get the data label and data value to display convert the data value to local
                        // string so it uses a comma seperated number
                        var dataLabel = data.labels[tooltipItem.index];
                        var value = ': Rp.' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString();

                        // make this isn't a multi-line label (e.g. [["label 1 - line 1, "line 2, ],
                        // [etc...]])
                        if (Chart.helpers.isArray(dataLabel)) {
                            // show value on first line of multiline label need to clone because we are
                            // changing the value
                            dataLabel = dataLabel.slice();
                            dataLabel[0] += value;
                        } else {
                            dataLabel += value;
                        }

                        // return the text to display on the tooltip
                        return dataLabel;
                    }
                }
            },
            barValueSpacing: 20,
            scales: {
                xAxes: [
                    {
                        barPercentage: 1,
                        categoryPercentage: 0.6
                    }
                ],
                yAxes: [
                    {
                        ticks: {
                            min: 0
                        }
                    }
                ]
            }
        }
    });
</script>
<script>
    // Set new default font family and font color to mimic Bootstrap's default
    // styling
    Chart.defaults.global.defaultFontFamily = 'Nunito',
        '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",' +
        'Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';

    // Pie Chart Example
    var ctx = document.getElementById("pieRealisasi");
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: [
                "Air Bersih", "Kebersihan", "Keamanan & IPK", "Listrik"
            ],
            datasets: [
                {
                    data: [
                        <?php echo e($reaAirBersih); ?>, <?php echo e($reaKebersihan); ?>, <?php echo e($reaKeamananIpk); ?>, <?php echo e($reaListrik); ?>

                    ],
                    backgroundColor: [
                        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e'
                    ],
                    hoverBackgroundColor: [
                        '#2e59d9', '#17a673', '#2c9faf', '#dda20a'
                    ],
                    hoverBorderColor: "rgba(234, 236, 244, 1)"
                }
            ]
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                enabled: true,
                callbacks: {
                    // this callback is used to create the tooltip label
                    label: function (tooltipItem, data) {
                        // get the data label and data value to display convert the data value to local
                        // string so it uses a comma seperated number
                        var dataLabel = data.labels[tooltipItem.index];
                        var value = ' : Rp ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString();

                        // make this isn't a multi-line label (e.g. [["label 1 - line 1, "line 2, ],
                        // [etc...]])
                        if (Chart.helpers.isArray(dataLabel)) {
                            // show value on first line of multiline label need to clone because we are
                            // changing the value
                            dataLabel = dataLabel.slice();
                            dataLabel[0] += value;
                        } else {
                            dataLabel += value;
                        }

                        // return the text to display on the tooltip
                        return dataLabel;
                    }
                },
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10
            },
            legend: {
                display: false
            },
            cutoutPercentage: 50,
            rotation: 10
        }
    });

    // Set new default font family and font color to mimic Bootstrap's default
    // styling
    Chart.defaults.global.defaultFontFamily = 'Nunito',
        '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",' +
        'Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';

    // Pie Chart Example
    var ctx = document.getElementById("pieSelisih");
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: [
                "Air Bersih", "Kebersihan", "Keamanan & IPK", "Listrik"
            ],
            datasets: [
                {
                    data: [
                        <?php echo e($selAirBersih); ?>, <?php echo e($selKebersihan); ?>, <?php echo e($selKeamananIpk); ?>, <?php echo e($selListrik); ?>

                    ],
                    backgroundColor: [
                        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e'
                    ],
                    hoverBackgroundColor: [
                        '#2e59d9', '#17a673', '#2c9faf', '#dda20a'
                    ],
                    hoverBorderColor: "rgba(234, 236, 244, 1)"
                }
            ]
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                enabled: true,
                callbacks: {
                    // this callback is used to create the tooltip label
                    label: function (tooltipItem, data) {
                        // get the data label and data value to display convert the data value to local
                        // string so it uses a comma seperated number
                        var dataLabel = data.labels[tooltipItem.index];
                        var value = ' : Rp ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString();

                        // make this isn't a multi-line label (e.g. [["label 1 - line 1, "line 2, ],
                        // [etc...]])
                        if (Chart.helpers.isArray(dataLabel)) {
                            // show value on first line of multiline label need to clone because we are
                            // changing the value
                            dataLabel = dataLabel.slice();
                            dataLabel[0] += value;
                        } else {
                            dataLabel += value;
                        }

                        // return the text to display on the tooltip
                        return dataLabel;
                    }
                },
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10
            },
            legend: {
                display: false
            },
            cutoutPercentage: 50,
            rotation: 10
        }
    });

    // Set new default font family and font color to mimic Bootstrap's default
    // styling
    Chart.defaults.global.defaultFontFamily = 'Nunito',
        '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",' +
        'Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';

    // Pie Chart Example
    var ctx = document.getElementById("piePengguna");
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: [
                "Air Bersih", "Kebersihan", "Keamanan & IPK", "Listrik"
            ],
            datasets: [
                {
                    data: [
                        <?php echo e($penggunaAirBersih); ?>, <?php echo e($penggunaKebersihan); ?>, <?php echo e($penggunaKeamananIpk); ?>, <?php echo e($penggunaListrik); ?>

                    ],
                    backgroundColor: [
                        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e'
                    ],
                    hoverBackgroundColor: [
                        '#2e59d9', '#17a673', '#2c9faf', '#dda20a'
                    ],
                    hoverBorderColor: "rgba(234, 236, 244, 1)"
                }
            ]
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                enabled: true,
                callbacks: {
                    // this callback is used to create the tooltip label
                    label: function (tooltipItem, data) {
                        // get the data label and data value to display convert the data value to local
                        // string so it uses a comma seperated number
                        var dataLabel = data.labels[tooltipItem.index];
                        var value = ' : ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index].toLocaleString() + ' Pengguna';

                        // make this isn't a multi-line label (e.g. [["label 1 - line 1, "line 2, ],
                        // [etc...]])
                        if (Chart.helpers.isArray(dataLabel)) {
                            // show value on first line of multiline label need to clone because we are
                            // changing the value
                            dataLabel = dataLabel.slice();
                            dataLabel[0] += value;
                        } else {
                            dataLabel += value;
                        }

                        // return the text to display on the tooltip
                        return dataLabel;
                    }
                },
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10
            },
            legend: {
                display: false
            },
            cutoutPercentage: 50,
            rotation: 10
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\CaringinBest\resources\views/master/index.blade.php ENDPATH**/ ?>