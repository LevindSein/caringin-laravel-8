<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HariLiburController extends Controller
{
    //
}
